<?php

use App\Http\Controllers\AccountantPackController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\AttachmentController;
use App\Http\Controllers\BankImportController;
use App\Http\Controllers\ClaimController;
use App\Http\Controllers\CollectionsController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\FinanceController;
use App\Http\Controllers\FinanceReportController;
use App\Http\Controllers\ItemLibraryController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\JobVendorCostController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\OsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RecurringExpenseController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\TaxSummaryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VendorController;
use Illuminate\Support\Facades\Route;

// Kretiv OS: with the *_HOST env vars set each module answers only on its own
// subdomain; with none set everything runs on one host as before.
$host = fn (string $module) => config("kretivco.hosts.{$module}");
$onHost = fn (string $module, Closure $routes) => $host($module) ? Route::domain($host($module))->group($routes) : $routes();

// OS: login, launcher, Users & Access.
$osRoutes = function () {
    Route::middleware('auth')->group(function () {
        Route::get('/', [OsController::class, 'home'])->name('os.home');
        Route::get('/access', [OsController::class, 'access'])->name('os.access');
        Route::put('/access/{user}', [OsController::class, 'updateAccess'])->name('os.access.update');
    });
};
if ($host('os')) {
    Route::domain($host('os'))->group($osRoutes);
    Route::domain($host('os'))->group(base_path('routes/auth.php'));
} else {
    Route::prefix('os')->group($osRoutes);
    require __DIR__.'/auth.php';
}

$onHost('jobs', function () {
    Route::get('/', function () {
        return redirect()->route(auth()->check() ? 'dashboard' : 'login');
    })->name('jobs.home');

    Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'verified', 'module:jobs'])->name('dashboard');

    Route::middleware('auth')->group(function () {
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    Route::middleware(['auth', 'module:jobs'])->group(function () {
        Route::get('/settings', [UserController::class, 'index'])->name('settings.index');
        Route::post('/settings/users', [UserController::class, 'store'])->name('settings.users.store');
        Route::put('/settings/users/{user}', [UserController::class, 'update'])->name('settings.users.update');
        Route::post('/settings/users/{user}/toggle-active', [UserController::class, 'toggleActive'])->name('settings.users.toggle-active');
        Route::post('/settings/users/{user}/reset-password', [UserController::class, 'resetPassword'])->name('settings.users.reset-password');
        Route::post('/settings/reset-jobs', [UserController::class, 'resetJobs'])->name('settings.reset-jobs');
        Route::post('/settings/reset-all-data', [UserController::class, 'resetAllData'])->name('settings.reset-all-data');
        Route::get('/customers', [CustomerController::class, 'index'])->name('customers.index');
        Route::get('/postcode-lookup/{postcode}', [CustomerController::class, 'postcodeLookup'])->name('postcode.lookup');
        Route::post('/customers', [CustomerController::class, 'store'])->name('customers.store');
        Route::put('/customers/{customer}', [CustomerController::class, 'update'])->name('customers.update');
        Route::get('/vendors', [VendorController::class, 'index'])->name('vendors.index');
        Route::post('/vendors', [VendorController::class, 'store'])->name('vendors.store');
        Route::put('/vendors/{vendor}', [VendorController::class, 'update'])->name('vendors.update');
        Route::get('/items', [ItemLibraryController::class, 'index'])->name('items.index');
        Route::get('/items/search', [ItemLibraryController::class, 'search'])->name('items.search');
        Route::post('/items', [ItemLibraryController::class, 'store'])->name('items.store');
        Route::put('/items/{item}', [ItemLibraryController::class, 'update'])->name('items.update');
        Route::delete('/items/{item}', [ItemLibraryController::class, 'destroy'])->name('items.destroy');
        Route::get('/jobs', [JobController::class, 'index'])->name('jobs.index');
        Route::get('/jobs/create', [JobController::class, 'create'])->name('jobs.create');
        Route::post('/jobs', [JobController::class, 'store'])->name('jobs.store');
        Route::post('/jobs/quotation-preview', [DocumentController::class, 'previewNewJob'])->name('jobs.quotation-preview');
        Route::get('/jobs/quotation-notes', [DocumentController::class, 'quotationNotes'])->name('jobs.quotation-notes');
        Route::get('/jobs/{job}', [JobController::class, 'show'])->name('jobs.show');
        Route::put('/jobs/{job}', [JobController::class, 'update'])->name('jobs.update');
        Route::delete('/jobs/{job}', [JobController::class, 'destroy'])->name('jobs.destroy');
        Route::put('/jobs/{job}/line-items', [JobController::class, 'updateLineItems'])->name('jobs.line-items.update');
        Route::post('/jobs/{job}/take-in', [JobController::class, 'takeIn'])->name('jobs.take-in');
        Route::post('/jobs/{job}/close-ticket', [JobController::class, 'closeTicket'])->name('jobs.close-ticket');
        Route::post('/jobs/{job}/complete', [JobController::class, 'complete'])->name('jobs.complete');
        Route::put('/jobs/{job}/reassign', [JobController::class, 'reassign'])->name('jobs.reassign');
        Route::post('/jobs/{job}/hold', [JobController::class, 'hold'])->name('jobs.hold');
        Route::post('/jobs/{job}/resume', [JobController::class, 'resume'])->name('jobs.resume');
        Route::post('/jobs/{job}/archive', [JobController::class, 'archive'])->name('jobs.archive');
        Route::post('/jobs/{job}/rollback', [JobController::class, 'rollback'])->name('jobs.rollback');
        Route::post('/jobs/{job}/notes', [JobController::class, 'addNote'])->name('jobs.notes.store');
        Route::get('/jobs/{job}/notes/{log}/attachments/{attachmentId}', [JobController::class, 'noteAttachment'])->name('jobs.notes.attachments.show');
        Route::post('/jobs/{job}/attachments', [AttachmentController::class, 'store'])->name('jobs.attachments.store');
        Route::get('/jobs/{job}/attachments/{attachmentId}', [AttachmentController::class, 'show'])->name('jobs.attachments.show');
        Route::delete('/jobs/{job}/attachments/{attachmentId}', [AttachmentController::class, 'destroy'])->name('jobs.attachments.destroy');
        Route::prefix('/jobs/{job}/documents/{type}')->whereIn('type', ['quotation', 'proforma', 'invoice', 'receipt'])->group(function () {
            Route::get('/draft', [DocumentController::class, 'draft'])->name('jobs.documents.draft');
            Route::post('/preview', [DocumentController::class, 'preview'])->name('jobs.documents.preview');
            Route::post('/save', [DocumentController::class, 'save'])->name('jobs.documents.save');
            Route::post('/generate', [DocumentController::class, 'generate'])->name('jobs.documents.generate');
        });
        Route::get('/jobs/{job}/documents/{document}', [DocumentController::class, 'showDocument'])->name('jobs.documents.show');
        Route::post('/jobs/{job}/documents/combine', [DocumentController::class, 'combine'])->name('jobs.documents.combine');
        Route::post('/jobs/{job}/payments/{entry}/void', [DocumentController::class, 'voidPayment'])->name('jobs.payments.void');
        Route::post('/jobs/{job}/vendor-costs', [JobVendorCostController::class, 'store'])->name('jobs.vendor-costs.store');
        Route::put('/jobs/{job}/vendor-costs/{costId}', [JobVendorCostController::class, 'update'])->name('jobs.vendor-costs.update');
        Route::delete('/jobs/{job}/vendor-costs/{costId}', [JobVendorCostController::class, 'destroy'])->name('jobs.vendor-costs.destroy');
        Route::post('/jobs/{job}/vendor-costs/{costId}/mark-paid', [JobVendorCostController::class, 'markPaid'])->name('jobs.vendor-costs.mark-paid');
        Route::get('/leads', [LeadController::class, 'index'])->name('leads.index');
        Route::get('/leads/create', [LeadController::class, 'create'])->name('leads.create');
        Route::post('/leads', [LeadController::class, 'store'])->name('leads.store');
        Route::get('/leads/{lead}', [LeadController::class, 'show'])->name('leads.show');
        Route::put('/leads/{lead}', [LeadController::class, 'update'])->name('leads.update');
        Route::post('/leads/{lead}/convert', [LeadController::class, 'convert'])->name('leads.convert');
        Route::post('/leads/{lead}/mark-lost', [LeadController::class, 'markLost'])->name('leads.mark-lost');
        Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
        Route::get('/reports/export', [ReportController::class, 'export'])->name('reports.export');
        Route::get('/departments', [DepartmentController::class, 'index'])->name('departments.index');
    });

});

// Finance: its own subdomain (finance.kretiv.co) when FINANCE_HOST is set,
// otherwise under /finance on the single host (local dev, tests).
$financeRoutes = function () {
    Route::middleware(['auth', 'module:finance'])->group(function () {
        Route::get('/', [FinanceController::class, 'index'])->name('finance.index');
        Route::get('/reports/{report}', [FinanceReportController::class, 'show'])->name('finance.reports');
        Route::post('/expense', [FinanceController::class, 'storeExpense'])->name('finance.expense.store');
        Route::post('/opening-balance', [FinanceController::class, 'storeOpeningBalance'])->name('finance.opening-balance.store');
        Route::post('/director-loan', [FinanceController::class, 'storeDirectorLoan'])->name('finance.director-loan.store');
        Route::post('/bank-transfer', [FinanceController::class, 'storeBankTransfer'])->name('finance.bank-transfer.store');
        Route::get('/ledger/{entry}/receipt', [FinanceController::class, 'showReceipt'])->name('finance.ledger.receipt');
        Route::get('/collections', [CollectionsController::class, 'index'])->name('finance.collections');
        Route::get('/recurring', [RecurringExpenseController::class, 'index'])->name('finance.recurring');
        Route::post('/recurring', [RecurringExpenseController::class, 'store'])->name('finance.recurring.store');
        Route::post('/recurring/{recurring}/record', [RecurringExpenseController::class, 'record'])->name('finance.recurring.record');
        Route::post('/recurring/{recurring}/toggle', [RecurringExpenseController::class, 'toggle'])->name('finance.recurring.toggle');
        Route::delete('/recurring/{recurring}', [RecurringExpenseController::class, 'destroy'])->name('finance.recurring.destroy');
        Route::get('/claims', [ClaimController::class, 'index'])->name('finance.claims');
        Route::post('/claims', [ClaimController::class, 'store'])->name('finance.claims.store');
        Route::post('/claims/{claim}/approve', [ClaimController::class, 'approve'])->name('finance.claims.approve');
        Route::post('/claims/{claim}/reject', [ClaimController::class, 'reject'])->name('finance.claims.reject');
        Route::post('/claims/{claim}/pay', [ClaimController::class, 'pay'])->name('finance.claims.pay');
        Route::get('/claims/{claim}/receipt', [ClaimController::class, 'receipt'])->name('finance.claims.receipt');
        Route::delete('/claims/{claim}', [ClaimController::class, 'destroy'])->name('finance.claims.destroy');
        Route::post('/ledger/{entry}/void', [FinanceController::class, 'voidEntry'])->name('finance.ledger.void');
        Route::get('/assets', [AssetController::class, 'index'])->name('finance.assets');
        Route::post('/assets', [AssetController::class, 'store'])->name('finance.assets.store');
        Route::post('/assets/{asset}/dispose', [AssetController::class, 'dispose'])->name('finance.assets.dispose');
        Route::delete('/assets/{asset}', [AssetController::class, 'destroy'])->name('finance.assets.destroy');
        Route::get('/tax', [TaxSummaryController::class, 'index'])->name('finance.tax');
        Route::post('/drawings', [FinanceController::class, 'storeDrawings'])->name('finance.drawings.store');
        Route::get('/accountant', [AccountantPackController::class, 'index'])->name('finance.accountant');
        Route::get('/accountant/download', [AccountantPackController::class, 'download'])->name('finance.accountant.download');
        Route::get('/bank-import', [BankImportController::class, 'index'])->name('finance.bank-import');
        Route::post('/bank-import', [BankImportController::class, 'upload'])->name('finance.bank-import.upload');
        Route::delete('/bank-import', [BankImportController::class, 'clear'])->name('finance.bank-import.clear');
    });
};
if ($host('finance')) {
    Route::domain($host('finance'))->group($financeRoutes);
} else {
    Route::prefix('finance')->group($financeRoutes);
}
